package com.medical.db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBConnection {
    private static final String URL = "jdbc:mysql://localhost:3306/medical_db";
    private static final String USER = "javauser";
    private static final String PASS = "1234";

    public static Connection getConnection() throws ClassNotFoundException, SQLException {
        // Φόρτωση του driver
        Class.forName("com.mysql.cj.jdbc.Driver");
        return DriverManager.getConnection(URL, USER, PASS);
    }
}