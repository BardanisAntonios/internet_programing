package com.medical.db;

import java.sql.*;
import com.medical.model.*;
import com.medical.utils.HashUtils;

public class UserDAO {

    public User authenticate(String username, String plainPassword) {
        String hashedPassword = HashUtils.hashPassword(plainPassword);
        
        try (Connection con = DBConnection.getConnection()) {
            String sql = "SELECT * FROM users WHERE username = ? AND password = ?";
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setString(1, username);
            ps.setString(2, hashedPassword);
            
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                // Επιστροφή αντικειμένου ανάλογα με τον ρόλο
                String role = rs.getString("role");
                int id = rs.getInt("id");
                String name = rs.getString("name");
                String surname = rs.getString("surname");
                
                if ("DOCTOR".equals(role)) return new Doctor(id, username, name, surname, "N/A"); 
                if ("PATIENT".equals(role)) return new Patient(id, username, name, surname, "N/A");
                if ("ADMIN".equals(role)) return new Admin(id, username, name, surname);
            }
        } catch (Exception e) { e.printStackTrace(); }
        return null;
    }

    // Μέθοδος για εγγραφή Γιατρού (από Admin)
    public boolean registerDoctor(String username, String password, String name, String surname, String specialty) {
        try (Connection con = DBConnection.getConnection()) {
            String hashedPassword = HashUtils.hashPassword(password);
            
            // 1. Insert User
            String sqlUser = "INSERT INTO users (username, password, name, surname, role) VALUES (?, ?, ?, ?, 'DOCTOR')";
            PreparedStatement ps = con.prepareStatement(sqlUser, Statement.RETURN_GENERATED_KEYS);
            ps.setString(1, username);
            ps.setString(2, hashedPassword);
            ps.setString(3, name);
            ps.setString(4, surname);
            ps.executeUpdate();
            
            ResultSet rs = ps.getGeneratedKeys();
            if (rs.next()) {
                int userId = rs.getInt(1);
                // 2. Insert Doctor details
                String sqlDoc = "INSERT INTO doctors (user_id, specialty) VALUES (?, ?)";
                PreparedStatement ps2 = con.prepareStatement(sqlDoc);
                ps2.setInt(1, userId);
                ps2.setString(2, specialty);
                ps2.executeUpdate();
                return true;
            }
        } catch (Exception e) { e.printStackTrace(); }
        return false;
    }
    
    // Μέθοδος για εγγραφή Ασθενή (Register form)
    public boolean registerPatient(String username, String password, String name, String surname, String amka) {
        try (Connection con = DBConnection.getConnection()) {
            String hashedPassword = HashUtils.hashPassword(password);
            
            String sqlUser = "INSERT INTO users (username, password, name, surname, role) VALUES (?, ?, ?, ?, 'PATIENT')";
            PreparedStatement ps = con.prepareStatement(sqlUser, Statement.RETURN_GENERATED_KEYS);
            ps.setString(1, username);
            ps.setString(2, hashedPassword);
            ps.setString(3, name);
            ps.setString(4, surname);
            ps.executeUpdate();
            
            ResultSet rs = ps.getGeneratedKeys();
            if (rs.next()) {
                int userId = rs.getInt(1);
                String sqlPat = "INSERT INTO patients (user_id, amka) VALUES (?, ?)";
                PreparedStatement ps2 = con.prepareStatement(sqlPat);
                ps2.setInt(1, userId);
                ps2.setString(2, amka);
                ps2.executeUpdate();
                return true;
            }
        } catch (Exception e) { e.printStackTrace(); }
        return false;
    }
    
    public boolean deleteDoctor(int doctorId) {
         try (Connection con = DBConnection.getConnection()) {
             // Λόγω του ON DELETE CASCADE στη βάση, αν σβήσουμε τον User σβήνονται όλα
             String sql = "DELETE FROM users WHERE id = ? AND role = 'DOCTOR'";
             PreparedStatement ps = con.prepareStatement(sql);
             ps.setInt(1, doctorId);
             return ps.executeUpdate() > 0;
         } catch (Exception e) { e.printStackTrace(); return false; }
    }
}
