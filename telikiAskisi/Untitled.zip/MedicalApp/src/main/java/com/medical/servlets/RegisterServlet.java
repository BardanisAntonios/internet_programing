package com.medical.servlets;

import java.io.IOException;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import com.medical.db.UserDAO;

@WebServlet("/RegisterServlet")
public class RegisterServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // 1. Λήψη κωδικοποίησης χαρακτήρων (για Ελληνικά)
        request.setCharacterEncoding("UTF-8");
        
        // 2. Λήψη παραμέτρων από τη φόρμα του index.jsp
        String username = request.getParameter("username");
        String password = request.getParameter("password");
        String name = request.getParameter("name");
        String surname = request.getParameter("surname");
        String amka = request.getParameter("amka");
        
        // 3. Δημιουργία του DAO
        UserDAO dao = new UserDAO();
        
        // 4. Κλήση της μεθόδου εγγραφής
        // Σημείωση: Η μέθοδος registerPatient στο DAO κάνει μόνη της το hashing του κωδικού.
        boolean success = dao.registerPatient(username, password, name, surname, amka);
        
        // 5. Ανακατεύθυνση ανάλογα με το αποτέλεσμα
        if (success) {
            // Επιτυχία: Πήγαινε πίσω στο Login και δείξε μήνυμα
            response.sendRedirect("index.jsp?msg=RegisteredSuccessfully");
        } else {
            // Αποτυχία (π.χ. το Username ή το ΑΜΚΑ υπάρχει ήδη): Δείξε σφάλμα
            response.sendRedirect("index.jsp?error=RegistrationFailed");
        }
    }
}