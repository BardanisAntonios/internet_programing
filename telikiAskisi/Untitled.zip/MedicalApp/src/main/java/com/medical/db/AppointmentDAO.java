package com.medical.db;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import com.medical.model.Appointment;

public class AppointmentDAO {

    // 1. Γιατρός: Προσθήκη Διαθεσιμότητας
    public void addAvailability(int doctorId, String dateTime) {
        try (Connection con = DBConnection.getConnection()) {
            String sql = "INSERT INTO appointments (doctor_id, date_time, status) VALUES (?, ?, 'AVAILABLE')";
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setInt(1, doctorId);
            ps.setString(2, dateTime); // Format: 'YYYY-MM-DD HH:MM:SS'
            ps.executeUpdate();
        } catch (Exception e) { e.printStackTrace(); }
    }

    // 2. Ασθενής: Κλείσιμο Ραντεβού
    public boolean bookAppointment(int appointmentId, int patientId) {
        try (Connection con = DBConnection.getConnection()) {
            // Κλειδώνουμε το ραντεβού μόνο αν είναι ακόμα AVAILABLE
            String sql = "UPDATE appointments SET patient_id = ?, status = 'BOOKED' WHERE id = ? AND status = 'AVAILABLE'";
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setInt(1, patientId);
            ps.setInt(2, appointmentId);
            return ps.executeUpdate() > 0;
        } catch (Exception e) { e.printStackTrace(); return false; }
    }

    // 3. Ακύρωση (Έλεγχος 3 ημερών)
    public boolean cancelAppointment(int appointmentId) {
        try (Connection con = DBConnection.getConnection()) {
            // Ελέγχουμε αν είναι 3 μέρες μετά
            String checkSql = "SELECT date_time FROM appointments WHERE id = ?";
            PreparedStatement psCheck = con.prepareStatement(checkSql);
            psCheck.setInt(1, appointmentId);
            ResultSet rs = psCheck.executeQuery();
            
            if (rs.next()) {
                Timestamp appDate = rs.getTimestamp("date_time");
                long threeDaysInMillis = 3L * 24 * 60 * 60 * 1000;
                
                // Αν η ημερομηνία ραντεβού είναι ΜΕΤΑ από (Τώρα + 3 μέρες)
                if (appDate.getTime() > (System.currentTimeMillis() + threeDaysInMillis)) {
                    String updateSql = "UPDATE appointments SET status = 'AVAILABLE', patient_id = NULL WHERE id = ?";
                    PreparedStatement psUpd = con.prepareStatement(updateSql);
                    psUpd.setInt(1, appointmentId);
                    psUpd.executeUpdate();
                    return true;
                }
            }
        } catch (Exception e) { e.printStackTrace(); }
        return false;
    }
    
    // 4. Λίστα Διαθέσιμων Ραντεβού (για Ασθενείς - για να κλείσουν νέο)
    public List<Appointment> getAvailableAppointments() {
        List<Appointment> list = new ArrayList<>();
        
        String sql = "SELECT a.id, a.date_time, u.name, u.surname, d.specialty " +
                     "FROM appointments a " +
                     "JOIN doctors d ON a.doctor_id = d.user_id " +
                     "JOIN users u ON d.user_id = u.id " +
                     "WHERE a.status = 'AVAILABLE' " +
                     "AND a.date_time > NOW() " + 
                     "ORDER BY a.date_time ASC";

        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                int id = rs.getInt("id");
                String dateTime = rs.getString("date_time");
                String doctorName = "Dr. " + rs.getString("surname") + " " + rs.getString("name");
                String specialty = rs.getString("specialty");
                
                Appointment app = new Appointment(
                    id, 
                    doctorName + " (" + specialty + ")", 
                    dateTime, 
                    "AVAILABLE"
                );
                list.add(app);
            }
        } catch (Exception e) { e.printStackTrace(); }
        return list;    
    }

    // 5. Μέθοδος για το πρόγραμμα του Γιατρού
    public List<Appointment> getDoctorSchedule(int doctorId) {
        List<Appointment> list = new ArrayList<>();
        
        String sql = "SELECT a.id, a.date_time, a.status, u.name, u.surname " +
                     "FROM appointments a " +
                     "LEFT JOIN patients p ON a.patient_id = p.user_id " +
                     "LEFT JOIN users u ON p.user_id = u.id " +
                     "WHERE a.doctor_id = ? " +
                     "ORDER BY a.date_time DESC";

        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                int id = rs.getInt("id");
                String dateTime = rs.getString("date_time");
                String status = rs.getString("status");
                
                String patientName = "Διαθέσιμο"; 
                if (rs.getString("surname") != null) {
                    patientName = rs.getString("surname") + " " + rs.getString("name");
                }

                list.add(new Appointment(id, patientName, dateTime, status));
            }
        } catch (Exception e) { e.printStackTrace(); }
        return list;
    }

 // 6. Μέθοδος για το Ιστορικό Ραντεβού του Ασθενή
    public List<Appointment> getAppointments(int patientId) {
        List<Appointment> list = new ArrayList<>();
        
        String sql = "SELECT a.id, a.date_time, a.status, u.surname, u.name, d.specialty " +
                     "FROM appointments a " +
                     "JOIN doctors d ON a.doctor_id = d.user_id " +
                     "JOIN users u ON d.user_id = u.id " +
                     "WHERE a.patient_id = ? " +
                     "ORDER BY a.date_time DESC";


        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            
            ps.setInt(1, patientId); 

            // Εκτελούμε το query και παίρνουμε τα αποτελέσματα
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    int id = rs.getInt("id");
                    String dateTime = rs.getString("date_time");
                    String status = rs.getString("status");
                    
                    String doctorInfo = "Dr. " + rs.getString("surname") + " (" + rs.getString("specialty") + ")";
                    
                    list.add(new Appointment(id, doctorInfo, dateTime, status));
                }
            }
        } catch (Exception e) { e.printStackTrace(); }
        return list;
    }
}