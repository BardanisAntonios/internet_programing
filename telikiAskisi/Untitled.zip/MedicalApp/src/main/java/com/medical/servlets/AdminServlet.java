package com.medical.servlets;

import java.io.IOException;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import com.medical.db.UserDAO;

@WebServlet("/AdminServlet")
public class AdminServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String action = request.getParameter("action");
        UserDAO dao = new UserDAO();
        
        if ("addDoctor".equals(action)) {
            dao.registerDoctor(
                request.getParameter("username"),
                request.getParameter("password"), // Plain text, το DAO θα το κάνει hash
                request.getParameter("name"),
                request.getParameter("surname"),
                request.getParameter("specialty")
            );
        } else if ("deleteDoctor".equals(action)) {
            int id = Integer.parseInt(request.getParameter("doctorId"));
            dao.deleteDoctor(id);
        }
        response.sendRedirect("admin/dashboard.jsp");
    }
}