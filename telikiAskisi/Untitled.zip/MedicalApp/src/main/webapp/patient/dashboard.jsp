<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ page import="java.util.List" %>
<%@ page import="com.medical.model.*" %>
<%@ page import="com.medical.db.AppointmentDAO" %>

<%
    // 1. Έλεγχος Ασφάλειας: Είναι ο χρήστης συνδεδεμένος και είναι Ασθενής;
    User user = (User) session.getAttribute("user");
    if (user == null || !(user instanceof Patient)) {
        response.sendRedirect("../index.jsp");
        return;
    }
    
    // Cast σε Patient για να πάρουμε τυχόν εξτρα στοιχεία αν χρειαστεί (π.χ. AMKA)
    Patient patient = (Patient) user;

    // 2. Ανάκτηση Δεδομένων από τη Βάση
    AppointmentDAO dao = new AppointmentDAO();
    
    // Λίστα Α: Διαθέσιμα ραντεβού για κλείσιμο (από όλους τους γιατρούς)
    List<Appointment> availableApps = dao.getAvailableAppointments();
    
    // Λίστα Β: Τα ραντεβού του συγκεκριμένου ασθενή (Ιστορικό)
    // ΣΗΜΕΙΩΣΗ: Η μέθοδος getAppointments(id) υπάρχει στο DAO (από την Άσκηση 2)
    List<Appointment> myApps = dao.getAppointments(patient.getId());
    
    // 3. Διαχείριση Μηνυμάτων (από ActionServlet)
    String msg = request.getParameter("msg");
%>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Καρτέλα Ασθενή</title>
    <style>
        body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; margin: 20px; background-color: #f9f9f9; }
        h1, h2 { color: #333; }
        .header { display: flex; justify-content: space-between; align-items: center; background: #fff; padding: 15px; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.1); }
        .logout-btn { text-decoration: none; color: white; background-color: #d9534f; padding: 8px 15px; border-radius: 4px; }
        
        table { width: 100%; border-collapse: collapse; margin-top: 15px; background: #fff; box-shadow: 0 2px 4px rgba(0,0,0,0.05); }
        th, td { padding: 12px; border-bottom: 1px solid #ddd; text-align: left; }
        th { background-color: #007BFF; color: white; }
        tr:hover { background-color: #f1f1f1; }
        
        .btn-book { background-color: #5cb85c; color: white; border: none; padding: 6px 12px; cursor: pointer; border-radius: 4px; }
        .btn-cancel { background-color: #d9534f; color: white; border: none; padding: 6px 12px; cursor: pointer; border-radius: 4px; }
        
        .alert { padding: 10px; margin-bottom: 15px; border-radius: 4px; }
        .success { background-color: #dff0d8; color: #3c763d; border: 1px solid #d6e9c6; }
        .error { background-color: #f2dede; color: #a94442; border: 1px solid #ebccd1; }
    </style>
</head>
<body>

    <!-- Header -->
    <div class="header">
        <div>
            <h1>Καλώς ήλθατε, <%= user.getName() %> <%= user.getSurname() %></h1>
            <small>Role: Patient | AMKA: <%= patient.getAmka() %></small>
        </div>
        <a href="../AuthServlet?action=logout" class="logout-btn">Αποσύνδεση</a>
    </div>

    <br>

    <!-- Μηνύματα Επιτυχίας/Λάθους -->
    <% if ("Cancelled".equals(msg)) { %>
        <div class="alert success">Το ραντεβού ακυρώθηκε επιτυχώς.</div>
    <% } else if ("CannotCancel_TooLate".equals(msg)) { %>
        <div class="alert error">Δεν μπορείτε να ακυρώσετε το ραντεβού (λιγότερο από 3 ημέρες πριν).</div>
    <% } %>

    <!-- Τμήμα 1: Διαθέσιμα Ραντεβού -->
    <h2>📅 Κλείσιμο Νέου Ραντεβού</h2>
    <% if (availableApps.isEmpty()) { %>
        <p>Δεν υπάρχουν διαθέσιμα ραντεβού αυτή τη στιγμή.</p>
    <% } else { %>
        <table>
            <thead>
                <tr>
                    <th>Γιατρός (Ειδικότητα)</th>
                    <th>Ημερομηνία & Ώρα</th>
                    <th>Ενέργεια</th>
                </tr>
            </thead>
            <tbody>
                <% for (Appointment app : availableApps) { %>
                <tr>
                    <td><%= app.getDoctorName() %></td>
                    <td><%= app.getDateTime() %></td>
                    <td>
                        <form action="../ActionServlet" method="post">
                            <input type="hidden" name="action" value="book">
                            <input type="hidden" name="appId" value="<%= app.getId() %>">
                            <button type="submit" class="btn-book">Κράτηση</button>
                        </form>
                    </td>
                </tr>
                <% } %>
            </tbody>
        </table>
    <% } %>

    <br><hr><br>

    <!-- Τμήμα 2: Ιστορικό Ραντεβού -->
    <h2>🗂️ Τα Ραντεβού μου</h2>
    <% if (myApps.isEmpty()) { %>
        <p>Δεν έχετε ιστορικό ραντεβού.</p>
    <% } else { %>
        <table>
            <thead>
                <tr>
                    <th>Γιατρός</th>
                    <th>Ημερομηνία & Ώρα</th>
                    <th>Κατάσταση</th>
                    <th>Ενέργειες</th>
                </tr>
            </thead>
            <tbody>
                <% for (Appointment app : myApps) { %>
                <tr>
                    <td><%= app.getDoctorName() %></td>
                    <td><%= app.getDateTime() %></td>
                    <td>
                        <% if ("BOOKED".equals(app.getStatus())) { %>
                            <span style="color: blue; font-weight: bold;">Προγραμματισμένο</span>
                        <% } else if ("COMPLETED".equals(app.getStatus())) { %>
                            <span style="color: green;">Ολοκληρωμένο</span>
                        <% } else if ("CANCELLED".equals(app.getStatus())) { %>
                            <span style="color: red;">Ακυρωμένο</span>
                        <% } else { %>
                            <%= app.getStatus() %>
                        <% } %>
                    </td>
                    <td>
                        <!-- Κουμπί Ακύρωσης: Μόνο αν δεν είναι ήδη ακυρωμένο ή ολοκληρωμένο -->
                        <% if ("BOOKED".equals(app.getStatus())) { %>
                        <form action="../ActionServlet" method="post" onsubmit="return confirm('Είστε σίγουροι ότι θέλετε να ακυρώσετε το ραντεβού;');">
                            <input type="hidden" name="action" value="cancel">
                            <input type="hidden" name="appId" value="<%= app.getId() %>">
                            <button type="submit" class="btn-cancel">Ακύρωση</button>
                        </form>
                        <% } else { %>
                            -
                        <% } %>
                    </td>
                </tr>
                <% } %>
            </tbody>
        </table>
    <% } %>

</body>
</html>