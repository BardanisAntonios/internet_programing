<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ page import="com.medical.model.Patient" %>
<%@ page import="com.medical.model.Appointment" %>
<%@ page import="java.util.List" %>

<%
    // Έλεγχος αν είναι συνδεδεμένος
    Patient p = (Patient) session.getAttribute("currentPatient");
    if (p == null) {
        response.sendRedirect("index.html");
        return;
    }
    List<Appointment> apps = (List<Appointment>) session.getAttribute("appointmentsList");
%>

<!DOCTYPE html>
<html>
<head>
    <title>Καρτέλα Ασθενή</title>
    <style>
        body { font-family: sans-serif; padding: 20px; }
        .header { background-color: #f4f4f4; padding: 10px; border-bottom: 2px solid #333; }
        table { width: 100%; border-collapse: collapse; margin-top: 20px; }
        th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }
        th { background-color: #007BFF; color: white; }
        .logout { float: right; color: red; text-decoration: none; }
    </style>
</head>
<body>
    <div class="header">
        <a href="PatientServlet?action=logout" class="logout">Αποσύνδεση</a>
        <h1>Καλώς ήλθατε, <%= p.getName() %> <%= p.getSurname() %></h1>
        <p><strong>AMKA:</strong> <%= p.getAmka() %></p>
    </div>

    <h3>Ιστορικό Ραντεβού</h3>
    <% if (apps != null && !apps.isEmpty()) { %>
        <table>
            <tr>
                <th>Γιατρός</th>
                <th>Ημερομηνία & Ώρα</th>
                <th>Κατάσταση</th>
            </tr>
            <% for (Appointment a : apps) { %>
            <tr>
                <td><%= a.getDoctorName() %></td>
                <td><%= a.getDateTime() %></td>
                <td><%= a.getStatus() %></td>
            </tr>
            <% } %>
        </table>
    <% } else { %>
        <p>Δεν βρέθηκαν ραντεβού.</p>
    <% } %>
</body>
</html>