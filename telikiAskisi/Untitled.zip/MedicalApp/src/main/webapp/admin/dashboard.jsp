<%@ page import="com.medical.model.*" %>
<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%
    User user = (User) session.getAttribute("user");
    if (user == null || ! (user instanceof Admin)) { response.sendRedirect("../index.jsp"); return; }
%>
<h1>Admin Dashboard</h1>
<p>Welcome, <%= user.getName() %></p>
<a href="../AuthServlet?action=logout">Logout</a>

<h3>Προσθήκη Γιατρού</h3>
<form action="../AdminServlet" method="post">
    <input type="hidden" name="action" value="addDoctor">
    Username: <input type="text" name="username" required><br>
    Password: <input type="text" name="password" required><br>
    Name: <input type="text" name="name" required><br>
    Surname: <input type="text" name="surname" required><br>
    Specialty: <input type="text" name="specialty" required><br>
    <input type="submit" value="Add Doctor">
</form>