<%@ page import="com.medical.model.*" %>
<%@ page import="java.util.List" %>
<%@ page import="com.medical.db.AppointmentDAO" %>
<%@ page import="com.medical.model.Appointment" %>
<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%
    User user = (User) session.getAttribute("user");
    if (user == null || ! (user instanceof Doctor)) { response.sendRedirect("../index.jsp"); return; }
%>
<h1>Doctor Dashboard</h1>
<p>Welcome, Dr. <%= user.getSurname() %></p>

<h3>Ορισμός Διαθεσιμότητας</h3>
<form action="../ActionServlet" method="post">
    <input type="hidden" name="action" value="addAvailability">
    Ημερομηνία: <input type="date" name="date" required>
    Ώρα: <input type="time" name="time" required>
    <input type="submit" value="Προσθήκη">
</form>


<hr>
<h3>Το Πρόγραμμά μου</h3>

<%
    // 1. Δημιουργία DAO και ανάκτηση λίστας
    AppointmentDAO dao = new AppointmentDAO();
    // Το user.getId() επιστρέφει το ID του γιατρού που είναι συνδεδεμένος
    List<Appointment> myAppointments = dao.getDoctorSchedule(user.getId());

    // 2. Έλεγχος αν η λίστα είναι κενή
    if (myAppointments.isEmpty()) {
%>
    <p>Δεν υπάρχουν καταχωρημένα ραντεβού.</p>
<%
    } else {
%>
    <!-- 3. Εμφάνιση Πίνακα -->
    <table border="1" cellpadding="10" style="border-collapse: collapse; width: 100%;">
        <thead>
            <tr style="background-color: #f2f2f2;">
                <th>Ημερομηνία & Ώρα</th>
                <th>Ασθενής / Κατάσταση</th>
                <th>Status</th>
                <th>Ενέργειες</th>
            </tr>
        </thead>
        <tbody>
            <% for (Appointment app : myAppointments) { %>
            <tr>
                <td><%= app.getDateTime() %></td>
                <td>
                    <!-- Εμφανίζουμε το όνομα του ασθενή που αποθηκεύσαμε στο αντικείμενο -->
                    <%= app.getDoctorName() %> 
                </td>
                <td>
                    <!-- Χρωματισμός ανάλογα με το Status -->
                    <% if ("AVAILABLE".equals(app.getStatus())) { %>
                        <span style="color: green; font-weight: bold;">Διαθέσιμο</span>
                    <% } else if ("BOOKED".equals(app.getStatus())) { %>
                        <span style="color: blue; font-weight: bold;">Κλεισμένο</span>
                    <% } else if ("CANCELLED".equals(app.getStatus())) { %>
                        <span style="color: red;">Ακυρωμένο</span>
                    <% } else { %>
                        <%= app.getStatus() %>
                    <% } %>
                </td>
                <td>
                    <!-- Κουμπί Ακύρωσης (Εμφανίζεται μόνο αν δεν είναι ήδη ακυρωμένο) -->
                    <% if (!"CANCELLED".equals(app.getStatus())) { %>
                    <form action="../ActionServlet" method="post" onsubmit="return confirm('Είστε σίγουροι για την ακύρωση;');">
                        <input type="hidden" name="action" value="cancel">
                        <input type="hidden" name="appId" value="<%= app.getId() %>">
                        <input type="submit" value="Ακύρωση" style="background-color: #ff4444; color: white; border: none; padding: 5px 10px; cursor: pointer;">
                    </form>
                    <% } else { %>
                        -
                    <% } %>
                </td>
            </tr>
            <% } %>
        </tbody>
    </table>
<%
    }
%>