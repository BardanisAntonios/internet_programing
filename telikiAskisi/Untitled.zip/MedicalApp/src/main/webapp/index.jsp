<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head><title>Medical Login</title></head>
<body>
    <h2>Medical System Login</h2>
    <form action="AuthServlet" method="post">
        Username: <input type="text" name="username"><br>
        Password: <input type="password" name="password"><br>
        <input type="submit" value="Login">
    </form>
    
    <hr>
    <h3>Εγγραφή Ασθενή</h3>
    <form action="RegisterServlet" method="post"> <!-- Θα χρειαστείς ένα απλό RegisterServlet -->
        <!-- Πεδία εγγραφής -->
    </form>
    
    <hr>
<h3>Εγγραφή Νέου Ασθενή</h3>

<!-- Εμφάνιση μηνυμάτων -->
<% if ("RegisteredSuccessfully".equals(request.getParameter("msg"))) { %>
    <p style="color: green; font-weight: bold;">Η εγγραφή ολοκληρώθηκε! Μπορείτε να συνδεθείτε.</p>
<% } else if ("RegistrationFailed".equals(request.getParameter("error"))) { %>
    <p style="color: red; font-weight: bold;">Η εγγραφή απέτυχε. Το Username ή το ΑΜΚΑ χρησιμοποιείται ήδη.</p>
<% } %>

<form action="RegisterServlet" method="post">
    <label>Username:</label><br>
    <input type="text" name="username" required><br>
    
    <label>Password:</label><br>
    <input type="password" name="password" required><br>
    
    <label>Όνομα:</label><br>
    <input type="text" name="name" required><br>
    
    <label>Επίθετο:</label><br>
    <input type="text" name="surname" required><br>
    
    <label>AMKA:</label><br>
    <input type="text" name="amka" required maxlength="11"><br><br>
    
    <input type="submit" value="Εγγραφή">
</form>
</body>
</html>